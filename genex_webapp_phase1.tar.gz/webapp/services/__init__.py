"""
Services Package
================
Business logic layer - separates data operations from routes.
"""

# Services will be implemented in Phase 2
# These will handle the coordination between routes, agents, and database
